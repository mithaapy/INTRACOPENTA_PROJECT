<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
 
<html>
 
<head>
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8">
    <title>Site Maintenance</title>
    <style type="text/css">
      body { text-align: center; padding: 150px; }
      h1 { font-size: 50px; }
      body { font: 20px Helvetica, sans-serif; color: #333; }
      #article { display: block; text-align: left; width: 650px; margin: 0 auto; }
      a { color: #dc8100; text-decoration: none; }
      a:hover { color: #333; text-decoration: none; }
    </style>
 
</head>
<body>
    <div id="article">
    <h1>We&rsquo;ll be back soon!</h1>
    <div><br/><br/><br/><br/>
        <p>Sorry for the inconvenience but we&rsquo;re performing some maintenance at the moment. If you need to you can always contact me on <b>kuncoro.wicaksono.adi.baroto@ericsson.com</b> or by ext. phone : +62 21 769 2222 - <b>9731</b>, otherwise we&rsquo;ll be back online shortly!  </p>
        <br/><br/><br/><br/><br/><br/><br/><p>&mdash; EID ERICSSON</p>
<button style="position:fixed; left:10px; bottom:10px;background: #f22d0c;border-radius: 50%;color: white;border: 0px;width: 100px;height: 100px;bottom: 10px;" onclick="history.go(-1);">Back </button>
    </div>
    </div>
</body>
</html>